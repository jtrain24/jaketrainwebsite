// Sticky Header on Scroll
const header = document.querySelector("header");
window.addEventListener("scroll", function() {
    header.classList.toggle("sticky", window.scrollY > 0);
    menuIcon.classList.remove('bx-x');
    navList.classList.remove('open');
});

// Mobile Menu Toggle
const menuIcon = document.getElementById('menu-icon');
const navList = document.querySelector('.navlist');

menuIcon.addEventListener('click', () => {
  navList.classList.toggle('open');
});

// Scroll Reveal Animations
const sr = ScrollReveal({
    distance: '30px',
    duration: 2600,
    reset: true
});

sr.reveal('.home-text', { delay: 280, origin: 'bottom' });
sr.reveal('.featured,.cta,.new,.brand,.contact', { delay: 200, origin: 'bottom' });

// Contact Form Validation (Vanilla JavaScript)
document.getElementById('contactForm').addEventListener('submit', function(event) {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;

    if (name === '') {
        alert('Please enter a name.');
        event.preventDefault(); // Prevent form submission
        return false;
    }

    if (email === '') {
        alert('Please enter an email address.');
        event.preventDefault(); // Prevent form submission
        return false;
    }

    alert('Thank you!');
});
